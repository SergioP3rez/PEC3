import org.apache.commons.codec.digest.DigestUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginForm {
    private JTextField userNameLogin;
    private JPasswordField passwordLogin;
    private JButton registerButtonLogin;
    private JButton loginButtonLogin;
    private JPanel LoginPanel;

    private JFrame frame = new JFrame("LoginForm");

    public LoginForm() {
        loginButtonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    DBConnection db = new DBConnection();
                    db.MySQLConnect();

                    String nombreDB = "users";

                    String userName = userNameLogin.getText();
                    String password = passwordLogin.getText();
                    String userCifrado = DigestUtils.sha256Hex(userName);
                    String passwordCifrado = DigestUtils.sha256Hex(password);

                    String Query = "SELECT * FROM "+nombreDB+" WHERE username='" + userCifrado+"'AND password='"+passwordCifrado+"' ";

                    db.comando = db.conexion.createStatement();
                    db.registro = db.comando.executeQuery(Query);

                    if(db.registro.next()){
                        JFrame aux = new JFrame();
                        JOptionPane.showMessageDialog(aux, "Succesfully logged!");
                    }else{
                        JFrame aux = new JFrame();
                        JOptionPane.showMessageDialog(aux, "Error: User is not registered");
                    }

                } catch (SQLException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        registerButtonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("RegisterForm");
                frame.setContentPane(new RegisterForm().RegisterPanel);
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("LoginForm");
        frame.setContentPane(new LoginForm().LoginPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }
}
