import org.apache.commons.codec.digest.DigestUtils;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RegisterForm {
    public JPanel RegisterPanel;
    public JTextField emailFieldRegister;
    public JTextField userNameFieldRegister;
    public JPasswordField passwordFieldRegister;
    public JPasswordField retypePasswordField;
    public JButton cancelButton;
    public JButton registerButtonRegister;

    public RegisterForm() {

        registerButtonRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    DBConnection db = new DBConnection();
                    db.MySQLConnect();

                    String nombreDB = "users";

                    String email = emailFieldRegister.getText();
                    String userName = userNameFieldRegister.getText();
                    String password = passwordFieldRegister.getText();
                    String userCifrado = DigestUtils.sha256Hex(userName);
                    String passwordCifrado = DigestUtils.sha256Hex(password);

                    String Query = "INSERT INTO "+nombreDB+"(username, password, mail) VALUES ('" + userCifrado+"', '"+passwordCifrado+"', '"+email+"')";

                    db.comando = db.conexion.createStatement();
                    int result = db.comando.executeUpdate(Query);
                    if(result==0){
                        JOptionPane.showMessageDialog(new JFrame(), "Something was wrong with the register.");
                    }else{
                        JOptionPane.showMessageDialog(new JFrame(), "Succesfully registered!");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
}
